import React, { useState, useEffect } from "react";
import { Bell, CheckCircle, AlertCircle, ShieldAlert } from "lucide-react";
import { api } from "../services/api";

export const PushSubscriber = ({ showToast }) => {
  const [permission, setPermission] = useState("default");
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (!("Notification" in window)) return;

    setPermission(Notification.permission);
    if (Notification.permission === "granted") {
      setIsSubscribed(true);
    }

    // Always attach the subscription listener, regardless of current permission,
    // so that a subId assigned *after* this mount (e.g. right after the user
    // grants permission via handleSubscribe) is still captured and synced.
    if (window.OneSignalDeferred) {
      window.OneSignalDeferred.push(async function (OneSignal) {
        try {
          const subId = OneSignal.User?.PushSubscription?.id;
          if (subId) {
            await api.subscribePush({
              userAgent: navigator.userAgent,
              subscribedAt: new Date().toISOString(),
              type: "browser_push",
              player_id: subId,
            });
            setIsSubscribed(true);
          }

          // Listen for subscription id assignment / changes (fires once OneSignal
          // finishes registering the browser's real push subscription).
          OneSignal.User?.PushSubscription?.addEventListener?.("change", async (event) => {
            const newId = event?.current?.id || OneSignal.User?.PushSubscription?.id;
            if (newId) {
              try {
                await api.subscribePush({
                  userAgent: navigator.userAgent,
                  subscribedAt: new Date().toISOString(),
                  type: "browser_push",
                  player_id: newId,
                });
                setIsSubscribed(true);
              } catch (e) {
                console.warn("Push sync failed on change event:", e);
              }
            }
          });
        } catch (err) {
          console.warn("OneSignal auto-sync error:", err);
        }
      });
    }
  }, []);

  const waitForOneSignalSubId = (timeoutMs = 8000, intervalMs = 400) =>
    new Promise((resolve) => {
      if (!window.OneSignalDeferred) {
        resolve(null);
        return;
      }
      window.OneSignalDeferred.push(async function (OneSignal) {
        const start = Date.now();
        const poll = () => {
          const subId = OneSignal.User?.PushSubscription?.id;
          if (subId) {
            resolve(subId);
          } else if (Date.now() - start >= timeoutMs) {
            resolve(null);
          } else {
            setTimeout(poll, intervalMs);
          }
        };
        poll();
      });
    });

  const handleSubscribe = async () => {
    if (!("Notification" in window)) {
      showToast("This browser does not support desktop push notifications.", "error");
      return;
    }

    if (!window.OneSignalDeferred) {
      showToast("OneSignal SDK failed to load. Check VITE_ONESIGNAL_APP_ID and network access to cdn.onesignal.com.", "error");
      return;
    }

    setIsProcessing(true);
    try {
      // Drive the permission request through OneSignal's own SDK and wait for
      // it to finish (it triggers the same native browser prompt internally).
      // Previously this also called the native Notification.requestPermission()
      // directly in parallel, which raced OneSignal's own call and could leave
      // the browser subscription registration incomplete even though the
      // native permission ended up "granted".
      const onesignalSubId = await new Promise((resolve) => {
        window.OneSignalDeferred.push(async function (OneSignal) {
          try {
            await OneSignal.Notifications.requestPermission();
            if (OneSignal.User?.PushSubscription?.optIn) {
              await OneSignal.User.PushSubscription.optIn();
            }
            resolve(OneSignal.User?.PushSubscription?.id || null);
          } catch (e) {
            console.warn("OneSignal prompt error:", e);
            resolve(null);
          }
        });
      });

      const perm = Notification.permission;
      setPermission(perm);

      if (perm === "granted") {
        const subscriptionData = {
          userAgent: navigator.userAgent,
          subscribedAt: new Date().toISOString(),
          type: "browser_push",
        };

        // Wait for OneSignal to actually finish registering the browser's real
        // push subscription before syncing to the backend - sending without a
        // player_id means the backend has no valid device to target.
        const subId = onesignalSubId || (await waitForOneSignalSubId());
        if (subId) {
          subscriptionData.player_id = subId;
        } else {
          console.warn("OneSignal subscription id not ready yet; the 'change' listener will sync it once available.");
        }

        // Send subscription to backend
        await api.subscribePush(subscriptionData);
        setIsSubscribed(true);
        showToast(
          subId
            ? "Browser push notifications successfully enabled!"
            : "Permission granted. Finishing push registration in the background...",
          "success"
        );

        // Display sample confirmation notification
        new Notification("Web Push Enabled", {
          body: "You will now receive automated browser notifications from the system.",
          icon: "/favicon.ico",
        });
      } else if (perm === "denied") {
        showToast("Notification permission was denied in your browser settings.", "error");
      }
    } catch (err) {
      showToast(err.message || "Push subscription failed", "error");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div
      style={{
        background: "rgba(168, 85, 247, 0.08)",
        border: "1px solid rgba(168, 85, 247, 0.25)",
        borderRadius: "10px",
        padding: "16px 20px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "24px",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
        <div
          style={{
            background: "rgba(168, 85, 247, 0.2)",
            color: "#c084fc",
            width: "40px",
            height: "40px",
            borderRadius: "8px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Bell size={20} />
        </div>
        <div>
          <h4 style={{ fontSize: "0.95rem", fontWeight: "600", color: "#f3f4f6" }}>
            Browser Web Push Notifications (OneSignal)
          </h4>
          <p style={{ fontSize: "0.8rem", color: "#9ca3af", marginTop: "2px" }}>
            Status:{" "}
            {permission === "granted" ? (
              <span style={{ color: "#34d399", fontWeight: "600" }}>Active & Subscribed</span>
            ) : permission === "denied" ? (
              <span style={{ color: "#f87171", fontWeight: "600" }}>Blocked by Browser</span>
            ) : (
              <span style={{ color: "#fbbf24", fontWeight: "600" }}>Permission Not Yet Granted</span>
            )}
          </p>
        </div>
      </div>

      <div>
        {permission === "granted" ? (
          <span className="badge badge-success" style={{ padding: "6px 12px" }}>
            <CheckCircle size={14} /> Subscribed
          </span>
        ) : (
          <button
            className="btn btn-primary"
            style={{ background: "#9333ea", borderColor: "#a855f7" }}
            onClick={handleSubscribe}
            disabled={isProcessing}
          >
            <Bell size={15} />
            {isProcessing ? "Requesting..." : "Enable Push Notifications"}
          </button>
        )}
      </div>
    </div>
  );
};

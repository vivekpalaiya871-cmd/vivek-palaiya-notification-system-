"""Notification Core package initialization."""

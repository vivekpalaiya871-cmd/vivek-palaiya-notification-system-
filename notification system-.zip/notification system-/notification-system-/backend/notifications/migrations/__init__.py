"""Migrations package for notifications."""
